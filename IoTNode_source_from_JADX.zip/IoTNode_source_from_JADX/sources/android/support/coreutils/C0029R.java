package android.support.coreutils;

/* renamed from: android.support.coreutils.R */
public final class C0029R {
}
