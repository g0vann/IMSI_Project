package android.support.p003v7.transition;

import android.support.annotation.RestrictTo;
import android.view.ViewGroup;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
/* renamed from: android.support.v7.transition.ActionBarTransition */
public class ActionBarTransition {
    private static final boolean TRANSITIONS_ENABLED = false;
    private static final int TRANSITION_DURATION = 120;

    public static void beginDelayedTransition(ViewGroup sceneRoot) {
    }
}
