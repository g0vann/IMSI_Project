package android.support.graphics.drawable.animated;

/* renamed from: android.support.graphics.drawable.animated.R */
public final class C0033R {
}
