package android.support.graphics.drawable;

/* renamed from: android.support.graphics.drawable.R */
public final class C0032R {
}
