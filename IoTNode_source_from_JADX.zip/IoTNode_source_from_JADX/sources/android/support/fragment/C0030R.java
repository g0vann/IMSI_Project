package android.support.fragment;

/* renamed from: android.support.fragment.R */
public final class C0030R {
}
