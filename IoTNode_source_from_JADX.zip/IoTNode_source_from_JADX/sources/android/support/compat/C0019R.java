package android.support.compat;

/* renamed from: android.support.compat.R */
public final class C0019R {
}
